"""
Plane bridge for p5.js classes
------------------------------
Reads live plane data from dump1090 and shares it on your network as
simple JSON that p5.js sketches can load.

Run on the Mac (no extra installs needed):
    python3 bridge.py          # real planes from dump1090
    python3 bridge.py --demo   # fake planes, for testing without the antenna

Students load:  http://<this-mac-ip>:8000/planes.json
"""

import json, math, random, socket, sys, threading, time, urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

# ---- Settings you might change ------------------------------------------
DUMP1090_URL = "http://localhost:8080/data.json"
PORT = 8000
HOME_LAT, HOME_LON = 51.50, -0.12   # where your antenna is (London default)
RANGE_KM = 150                      # distance from home to the edge of the canvas
# --------------------------------------------------------------------------

DEMO = "--demo" in sys.argv
latest = {"planes": [], "count": 0, "time": 0, "demo": DEMO}


def to_xy(lat, lon):
    """Turn lat/lon into x, y between 0 and 1 (home is 0.5, 0.5)."""
    dy_km = (lat - HOME_LAT) * 111.0
    dx_km = (lon - HOME_LON) * 111.0 * math.cos(math.radians(HOME_LAT))
    x = 0.5 + dx_km / (2 * RANGE_KM)
    y = 0.5 - dy_km / (2 * RANGE_KM)
    return round(x, 4), round(y, 4)


def tidy(raw):
    """Make one dump1090 plane beginner-friendly."""
    lat, lon = raw.get("lat", 0), raw.get("lon", 0)
    if lat == 0 and lon == 0:
        return None  # no position yet
    x, y = to_xy(lat, lon)
    return {
        "id": raw.get("hex", ""),
        "callsign": (raw.get("flight") or "").strip() or raw.get("hex", "?"),
        "lat": round(lat, 4),
        "lon": round(lon, 4),
        "altitude": raw.get("altitude", 0),  # feet
        "speed": raw.get("speed", 0),        # knots
        "heading": raw.get("track", 0),      # degrees, 0 = north
        "x": x,
        "y": y,
    }


# ---- Fake planes for --demo -------------------------------------------------
fake = [{
    "hex": f"demo{i:02d}",
    "flight": random.choice(["BAW", "EZY", "RYR", "VIR", "DLH"]) + str(random.randint(100, 999)),
    "lat": HOME_LAT + random.uniform(-1, 1),
    "lon": HOME_LON + random.uniform(-1.5, 1.5),
    "altitude": random.randint(3000, 38000),
    "speed": random.randint(180, 480),
    "track": random.randint(0, 359),
} for i in range(12)]


def move_fake():
    for p in fake:
        km = p["speed"] * 1.852 / 3600          # km moved in one second
        p["lat"] += km * math.cos(math.radians(p["track"])) / 111.0
        p["lon"] += km * math.sin(math.radians(p["track"])) / (111.0 * math.cos(math.radians(HOME_LAT)))
        if abs(p["lat"] - HOME_LAT) > 1.5 or abs(p["lon"] - HOME_LON) > 2.5:
            p["lat"], p["lon"] = HOME_LAT, HOME_LON   # fly off the edge -> restart
            p["track"] = random.randint(0, 359)
    return fake
# -----------------------------------------------------------------------------


def poll():
    global latest
    warned = False
    while True:
        try:
            if DEMO:
                raw = move_fake()
            else:
                with urllib.request.urlopen(DUMP1090_URL, timeout=2) as r:
                    raw = json.load(r)
                warned = False
            planes = [p for p in (tidy(r) for r in raw) if p]
            latest = {"planes": planes, "count": len(planes),
                      "time": int(time.time()), "demo": DEMO}
        except Exception as e:
            if not warned:
                print(f"Can't read dump1090 ({e}). Is it running with --net? "
                      f"Or try: python3 bridge.py --demo")
                warned = True
        time.sleep(1)


class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        # Let sketches on other computers read the data (CORS)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_GET(self):
        if self.path.split("?")[0] == "/planes.json":
            body = json.dumps(latest).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            super().do_GET()  # also serves files in this folder, e.g. sketch/

    def log_message(self, *args):
        pass  # keep the terminal quiet


def my_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "localhost"
    finally:
        s.close()


if __name__ == "__main__":
    threading.Thread(target=poll, daemon=True).start()
    ip = my_ip()
    print(f"{'DEMO MODE - fake planes' if DEMO else 'Reading ' + DUMP1090_URL}")
    print(f"Students use:  http://{ip}:{PORT}/planes.json")
    print(f"Starter sketch: http://{ip}:{PORT}/sketch/")
    print("Press Ctrl+C to stop.")
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
